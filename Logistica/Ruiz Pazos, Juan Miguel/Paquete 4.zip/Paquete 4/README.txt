En el paquete actual se incluyen las siguientes evidencias:

Evidencia 3 (30 min.) -> Dise�o de carteles de indicaci�n.

Evidencia 6 (45 min.) -> Reuni�n Log�stica 2.

Evidencia 8 (60 min.) -> Redise�o de carteles de indicaci�n.

Evidencia 10 (60 min.) -> Reuni�n Log�stica 4.

Evidencia 13 (60 min.) -> Moderaci�n Martes en el aula A2.16

Evidencia 15 (50 min.) -> Moderaci�n Viernes en el aula A2.12

Evidencia 17 (105 min.) -> Retirada de carteles de indicaci�n y otros materiales de las jornadas.






Los archivos que prueban la evidencia se encuentra adjunta en el mismo documento.pdf

****LAS HORAS DE ASISTENCIA DURANTE LAS JORNADAS NO EST�N INCLUIDAS****