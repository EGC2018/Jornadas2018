En el paquete actual se incluyen las siguientes evidencias:

Evidencia 7 (403 min.) -> Realizaci�n y posteriores modificaciones del v�deo promocional.







Los archivos que prueban la evidencia se encuentra adjunta en el mismo documento.pdf

****LAS HORAS DE ASISTENCIA DURANTE LAS JORNADAS NO EST�N INCLUIDAS****