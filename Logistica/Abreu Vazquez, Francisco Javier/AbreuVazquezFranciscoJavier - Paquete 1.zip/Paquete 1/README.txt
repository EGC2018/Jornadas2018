README paquete de evidencias 1

Horas totales: 14 horas 35 minutos

En este paquete recojo las evidencias de las reuniones de logística, de todos los documentos que he imprimido para las jornadas, de las veces que he sido encargado de una sede y de la creación del documento de adjudicación a ponentes