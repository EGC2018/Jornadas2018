En este paquete de evidencias he añadido todas aquellas relacionadas
con reuniones con el departamento de finanzas y a las generales de
presidencia.
Son un total de 7 reuniones, 4 de finanzas y 3 de presidencia.

Horas totales: 8h 9 min