Durante las Jornadas, gran parte de mi tiempo
ha sido dedicado a la campaña de ingresos del
departamento de finanzas. Me encargué de la búsqueda
de sponsors para las jornadas, de forma presencial y no presencial,
consiguiendo firmar 3 contratos con Abatic S.L, Geográphica S.L 
y  New Language Institute S.L recaudando un total de 400€ entre los 3.
Además, me encargué de realizar una plantilla de contrato de 
patrocinios, estuve recortando papeletas y he vendido 20 papeletas.

Tiempo dedicado en este paquete de evidencias:
Búsqueda y contacto con sponsors: 6h
Elaboración plantilla contrato:   1h 30 min
Contrato Abatic S.L:              3h
Contrato Geographica S.L:         2h
Contrato New Language Institute:  2h
Recorte de papeletas:             1h
Venta de 20 papeletas:            3h
    -------------------------------
Total                             18h 30min                                  
