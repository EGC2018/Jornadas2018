En este paquete de evidencias incluyo todas aquellas
relacionadas con el Networking/Desayuno del martes
y la comida del viernes que organicé junto con varios
compañeros, además de unas reuniones que tuvimos con
nuestros colaboradores, Ñam-Ñam y Calixto.
Las horas totales para este paquete de evidencias son:
Desayuno--------------------> 3h(Microtrabajo)
Comida----------------------> 6h30min(Microtrabajo)
Reuniones Ñam-Ñam y Calixto-> 2h
 ----------------------------------
 Total----------------------> 11h 30h
 11h 30 min sin contar con las horas que cuentan doble
 ni con la asistencia a las ponencias, que han sido 5h.
