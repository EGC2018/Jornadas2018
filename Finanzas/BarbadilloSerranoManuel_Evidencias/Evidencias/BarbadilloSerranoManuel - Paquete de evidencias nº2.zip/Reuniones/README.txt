Evidencias de Reuniones de Finanzas y Organizacion

Horas Invertidas:
	-Finanzas: 4 horas
	-Organizacion: 8 horas 23 mins

	-Totales: 12 horas 23 mins