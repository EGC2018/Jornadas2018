En este paquete se encuentra la evidencia referente a 
los presupuestos de las copister�as de Reina Mercedes. 

Horas invertidas: 2 horas y 30 minutos