En mis evidencias queda demostrado que como Coordinador de Programa del Grupo 2, junto con el Coordinador del grupo 1, he participado en el desarrollo del programa para las jornadas: He gestionado las ideas, comunicaciones con ponentes y horarios de las actividades del grupo 2, he trabajado con el Coordinador del grupo 1 para crear el documento de informaci�n del comit� de Programa, y he participado en la creaci�n de la Exposici�n que tuvo lugar en la sala de estudios. 

Adem�s, como Coordinador, he trabajado con el resto de Comit�s para resolver los problemas que fueron surgiendo durante la preparaci�n y desarrollo de las jornadas.

A parte de asistir a varias charlas, estuve en las jornadas ayudando en lo que pod�a: Montar los dos stands para los trivias y kahoot, atender a los ponentes de atSistemas, ayudar a repartir los regalos en el taller de adolescentes, etc.

En mis evidencias quedan registradas un total de 31 horas y 15 minutos de trabajo. Contando con el bonus de 23 horas de Coordinaci�n de Programa y 7 horas de asistencia. mi total de horas es de 61 horas y 15 minutos de trabajo.