Mi trabajo a nivel global en las jornadas ha sido la organizaci�n preparaci�n y desarrollo de la actividad del trivial
con un total de 21.5 horas invertidas, repartidas de la siguiente manera:

 Investigaci�n de Temas y preguntas para el Trivial--5 Horas
Redacci�n del documento de preguntas para el Trivial--6 Horas
B�squeda de medios necesarios para la realizaci�n de la actividad--0.5 horas
Montaje del stand para realizaci�n del Trivial--0.5 Horas 
Preparaci�n de las pruebas de preguntas del Trivial--2 Horas
Coordinaci�n y ejecuci�n de la actividad del Trivial en las Jornadas--6.5 Horas


Todo el trabajo realizado ha sido para el departamento de programa.