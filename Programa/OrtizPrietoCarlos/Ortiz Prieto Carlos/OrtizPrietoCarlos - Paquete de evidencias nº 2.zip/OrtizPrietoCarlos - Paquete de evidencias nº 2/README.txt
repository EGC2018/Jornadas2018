En este paquete he incluido las evidencias que hacen referencia a la ejecuci�n del escape room:
	1) El trabajo realizado como monitor.
	2) Diferentes documentos para controlar la asistencia a la actividad, as� como su organizaci�n.

La duraci�n de estas evidencias es de: 22:09 horas.
